 TOUR MANAGEMENT SYSTEM :
Previously people wishing to visit places had to manually search for available accommodation at the visiting places. Also they themselves had to make reservation. 
People hardly had any knowledge of which are the worth seeing places and about its history. Such procedure was time consuming and energy wasting.
Tour Reservation System has made life very easy for such visitors by saving both their time and energy.
Visitor requests for scheme to check the availability of the desired tour package. This information is stored in Tour Information System.
System will check whether the customer is existing or new. New user will enter his personal and tour details for reservation. 
In turn he/she will be provided with system generated unique ID and password. This login information could be used for further transactions.
When customer is satisfied with tour package he/she would request for reservation of tour. Personal details of new customer is stored in cust_info 
while the details regarding the tour selected by particular customer is stored in tour_info and the details regarding it would be restructured 
in Tour Information System.
Existing customer can update his/her personal details in cust_info and cancel reservation for tour from tour_info and changes regarding it are also
 reflected in Tour Information System.
After confirming the tour package the customer will make payment either online or through staff by personally going at the office. 
Customer can make payment by cash, credit card or by cheque.
System checks for the validity of staff. Once the payment is done by customer, valid staff will make Ticket Reservation System. .
Reserved customer will be able to view details about reservation by providing login information from cust_info and tour_info system.
Administrator can add, delete or modify tour schemes from Tour Information System.
NOTE:- TO FIND THE BOOKING PAGE , PLEASE FIND IN THE PACKAGE PAGE ..., WHICH REDIRECTS YOU THE NEW WEBSITE FOR THE BOOKING, YOU CAN BOOK BY FILLING THE BLANKS AS PER YOUR REQUIREMENTS.
  THANK YOU ..........